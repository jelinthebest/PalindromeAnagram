﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PalindromOrAnagram;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PalindromOrAnagram.Tests
{
    [TestClass()]
    public class PalindromeAnagramTests
    {
        [TestMethod()]
        public void IspalindromeTest()
        {
            PalindromeAnagram checkPalindrome = new PalindromeAnagram();
            Assert.AreEqual(true, checkPalindrome.Ispalindrome("anna"));
            Assert.AreEqual(true, checkPalindrome.Ispalindrome("aaaaaaaa"));
            Assert.AreEqual(true, checkPalindrome.Ispalindrome("aaaaaaaab"));
            Assert.AreEqual(false, checkPalindrome.Ispalindrome("caaaaaaaab"));
            Assert.AreEqual(true, checkPalindrome.Ispalindrome("donotbobtonod"));
            Assert.AreEqual(false, checkPalindrome.Ispalindrome("owefhijpfwai"));
            Assert.AreEqual(true, checkPalindrome.Ispalindrome("igdedgide"));
        }
    }
}