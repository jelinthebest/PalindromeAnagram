﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PalindromOrAnagram
{
    /* Assumptions:

       1. There will be no whitespace in the string.
       2.  All characters in the string will be lower case.
       3. The string will only contain alpha characters a-z.*/
    public class PalindromeAnagram
    {
         ///<summary>
        ///Check for the input string is palindrome or not . If string is palindrome return true or else
        ///check whether the string is anagram of palindrome.
        ///</summary>

        public bool Ispalindrome(string text)
        {
            bool isPalidrom = false;
            char[] charString = text.ToCharArray();
            Array.Reverse(charString);
            string reverseString = new string(charString);
            if (text == reverseString)
            {
                isPalidrom = true;
            }
            else
            {
                //is not palindrome, check if it is anagram of palindrome or not?
                isPalidrom = IspalindromeAnagram(text);
            }
            return isPalidrom;
        }

        //Check is it Anagram of a palindrome
        private bool IspalindromeAnagram(string text)
        {
            var arrCharCount = text.GroupBy(c => c, (c, wcount) => new
            {
               // character = c,
                count = wcount.Count()
            });
            /*Method 1:  Anagran of palindrome can be checked even with the below linq method. 
             Count the number of odd number of charactrs in the array. 
             Eg: word: abccdd;; Char array{a,b,c,d} Number array{1,1,2,2}  so Total odd char count is 2. 
             But better performance  use Method 2*/
            // return charCount.Count(c => c.count % 2 == 1) <= 1;

            /*Method 2: No need to count till end of the array if count alredy 2 */
            int oddCharCount = 0;
            bool isAnagramOfPlndrm = true;
            foreach (var eachCharCount in arrCharCount)
            {
                if (eachCharCount.count % 2 == 1)
                {
                    oddCharCount++;
                    if (oddCharCount > 1){break;}
                }
            }
            switch (oddCharCount)
            {
                case 0: isAnagramOfPlndrm = true;
                        break;
                case 1:
                    if (text.Length % 2 == 1) { isAnagramOfPlndrm = true; }
                    else {isAnagramOfPlndrm = false;}
                    break;
                default:
                    isAnagramOfPlndrm = false;
                    break;
            }
            return isAnagramOfPlndrm;
        }
    }
}
